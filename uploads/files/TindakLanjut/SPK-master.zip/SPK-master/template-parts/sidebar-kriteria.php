<aside class="sidebar">
	<div class="widget">
		<ul>
			<li><a href="list-kriteria.php">List Kriteria</a></li>
			<li><a href="tambah-kriteria.php">Tambah Kriteria</a></li>
		</ul>
	</div>
</aside>