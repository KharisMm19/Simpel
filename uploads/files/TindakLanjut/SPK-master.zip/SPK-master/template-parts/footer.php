	
	</div><!-- #main -->
	
	<footer id="footer">
		<div class="container">
			<p>Dibuat oleh <a href="https://github.com/zunan-umby" target="_blank">Zunan Arif R.</a></p>
		</div>
	</footer>

	</div><!-- #page -->
</body>
</html>
<?php
if(isset($pdo)) {
	// Tutup Koneksi
	$pdo = null;
}
?>