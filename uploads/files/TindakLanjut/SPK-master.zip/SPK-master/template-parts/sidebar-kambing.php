<aside class="sidebar">
	<div class="widget">
		<ul>
			<li><a href="list-kambing.php"><span class="fa fa-bars"></span> List Kambing</a></li>
			<li><a href="tambah-kambing.php"><span class="fa fa-plus"></span> Tambah Kambing</a></li>
		</ul>
	</div>
</aside>