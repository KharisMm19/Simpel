# SPK
Sistem pendukung keputusan dengan metode Topsis &amp; SAW.

 1. Buat database
 2. Import file database.sql
 3. Edit konfigurasi database di includes/konek-db.php
 4. Login dengan username: admin, password: admin
